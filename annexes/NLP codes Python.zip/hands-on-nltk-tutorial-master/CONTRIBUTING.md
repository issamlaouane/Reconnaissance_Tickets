# Contribution Guidelines

- The pull request and commit should have descriptive titles
- Make an individual pull request for each suggestion
- Check your spelling and grammar
- Make sure your editor is set to remove trailing whitespace.
